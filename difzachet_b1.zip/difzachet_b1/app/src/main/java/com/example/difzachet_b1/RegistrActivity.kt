package com.example.difzachet_b1

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class RegistrActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registr)
        val toRegisterButton = findViewById<Button>(R.id.registrbutone)
        sharedPreferences = getSharedPreferences("my_app_prefs", Context.MODE_PRIVATE)
        toRegisterButton.setOnClickListener {

            val loginTextView = findViewById<EditText>(R.id.login1)
            val passwordTextView = findViewById<EditText>(R.id.pass1)

            val username = loginTextView.text.toString().trim()
            val password = passwordTextView.text.toString().trim()

            if (username.isEmpty()) {
                Toast.makeText(this@RegistrActivity, "Введите логин", Toast.LENGTH_SHORT).show()
                if (password.isEmpty()) {
                    Toast.makeText(this@RegistrActivity, "Введите пароль", Toast.LENGTH_SHORT).show()
                }
            }
            else if (password.isEmpty()) {
                Toast.makeText(this@RegistrActivity, "Введите пароль", Toast.LENGTH_SHORT).show()
            }
            else{ // сохранение имя пользователя и пароля в SharedPreferences
                sharedPreferences.edit().putString("login", username).apply()
                sharedPreferences.edit().putString("password", password).apply()

                val alertDialogBuilder = AlertDialog.Builder(this)
                alertDialogBuilder.setTitle("Регистрация завершена")
                alertDialogBuilder.setMessage("Вы успешно зарегистрировались.")
                alertDialogBuilder.setPositiveButton("OK") { _, _ ->
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
                val alertDialog = alertDialogBuilder.create()
                alertDialog.show()
            }

        }
    }
}